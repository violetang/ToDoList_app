package com.example.violetang.navigationbuttom;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ItemDetail extends AppCompatActivity {

    private DatabaseHelper myDB;
    private Integer taskid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        myDB = new DatabaseHelper(this);

        TextView taskName = (TextView) findViewById(R.id.taskDetail_name);
        TextView taskDes = (TextView) findViewById(R.id.taskDetail_description);
        TextView taskDate = (TextView) findViewById(R.id.taskDetail_date);
        TextView taskList = (TextView) findViewById(R.id.taskDetail_list);

        Button btnEdit = (Button) findViewById(R.id.taskDetail_Edit);
        Button btnDelete = (Button) findViewById(R.id.taskDetail_Delete);

        /*======================================================================================
         * get the intent 's content from task_fragment ListView
         * by "TASK_ID"
       ======================================================================================*/
        Intent intent = getIntent();
        taskid = intent.getIntExtra("TASK_ID",0);
        //display("Come","okay "+taskid);

        /*======================================================================================
         * SQL query: get the task by given its ID;
         * And show the data into the front end
         * Has ERROR !!!! Guess it's because the SQL query has problem, getTaskbyId()
        ======================================================================================*/
        Cursor task_detail = myDB.getTaskbyId(taskid);
        if(task_detail.getCount() == 0){
            //message
            display("Error","NO Data Found.");
            return;
        }
        while(task_detail.moveToNext()){

            taskName.setText(task_detail.getString(1));
            taskDes.setText(task_detail.getString(2));
            taskDate.setText(task_detail.getString(3));
            taskList.setText(task_detail.getString(4));
        }

    }

    public void display(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

}
