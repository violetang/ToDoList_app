package com.example.violetang.navigationbuttom;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ItemAdapterTest extends BaseAdapter {

    LayoutInflater mInflater;
    ArrayList<String> task_items;
    ArrayList<String> task_descriptions;
    ArrayList<Integer>task_id;

    private DatabaseHelper myDB;

    //CheckBox[] task_checkbox;

    public ItemAdapterTest(Context c, ArrayList<Integer> id, ArrayList<String> i, ArrayList<String> d) {
        task_id = id;
        task_items = i;
        task_descriptions = d;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return task_items.size();
    }

    @Override
    public Object getItem(int position) {
        return task_items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = mInflater.inflate(R.layout.item_task, null);

        myDB = new DatabaseHelper(MyApplication.getAppContext());

        TextView nameTextView = (TextView) v.findViewById(R.id.taskName_TextView);
        TextView decriptionTextView = (TextView) v.findViewById(R.id.taskDes_TextView);
        //CheckBox taskCheckBox = (CheckBox)v.findViewById(R.id.taskCheckBox);
        ImageView imageView = (ImageView) v.findViewById(R.id.taskMenu_ImageView);

        final int index = position;

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.taskMenu_ImageView:

                        PopupMenu popup = new PopupMenu(MyApplication.getAppContext(), v);
                        popup.getMenuInflater().inflate(R.menu.taskitem_menu, popup.getMenu());
                        popup.show();
                        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.taskItemMenuEdit:

                                        //Or Some other code you want to put here.. This is just an example.
                                        Toast.makeText(MyApplication.getAppContext(), " Install Clicked at position " + " : " + index, Toast.LENGTH_LONG).show();

                                        break;
                                    case R.id.taskItemMenuDelete:
                                        int id = task_id.get(index);
                                        myDB.deleteTaskbyId(id);
                                        task_id.remove(index);
                                        task_descriptions.remove(index);
                                        task_items.remove(index);
                                        //Toast.makeText(MyApplication.getAppContext(), "task " + id+" was deleted", Toast.LENGTH_LONG).show();
                                        break;

                                    case R.id.taskItemMenuShare:
                                        //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                        break;

                                    default:
                                        break;
                                }

                                return true;
                            }
                        });
                        break;
                    default:
                        break;
                }
            }
        });

        String name = task_items.get(position);
        String desc = task_descriptions.get(position);
        //CheckBox checkbox = task_checkbox[position];

        nameTextView.setText(name);
        decriptionTextView.setText(desc);
        //taskCheckBox.onCheckboxClicked(checkbox);

        return v;
    }

}    /*
    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.checkbox_meat:
                if (checked)
                // Put some meat on the sandwich
            else
                // Remove the meat
                break;
            case R.id.checkbox_cheese:
                if (checked)
                // Cheese me
            else
                // I'm lactose intolerant
                break;
            // TODO: Veggie sandwich
        }
    }
    */
