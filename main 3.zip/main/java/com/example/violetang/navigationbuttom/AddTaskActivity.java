package com.example.violetang.navigationbuttom;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class AddTaskActivity extends AppCompatActivity {
    private String task_name;
    private String task_des;
    private String task_date;
    private String task_time;
    private int task_priority;
    private String task_share;

    private Button btnCancel;
    private Button btnDone;

    EditText tname, tdes;
    //Spinner tpri;

    private DatabaseHelper myDB;
    private SQLiteDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        myDB = new DatabaseHelper(this);

        tname = (EditText)findViewById(R.id.addtask_name);
        tdes = (EditText)findViewById(R.id.addtask_description);
        //tpri = (Spinner)findViewById(R.id.addtask_priority);

        btnCancel = (Button)findViewById(R.id.addtask_cancle);
        btnDone = (Button)findViewById(R.id.addtask_Done);

        addTask();
        viewTask();
    }

    public void addTask(){
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get the input
                task_name = tname.getText().toString();
                task_des = tdes.getText().toString();
                task_priority = 0; //priority defalut was 0

                //insert the task into database
                if(task_name.length() != 0){ //valid input
                    boolean insertTask = myDB.addTaskData(task_name,task_des,task_priority);
                    if(insertTask){
                        //jump back to the task page
                        Intent intent_back_to_task = new Intent(AddTaskActivity.this, MainActivity.class);
                        startActivity(intent_back_to_task);
                        //Toast.makeText(AddTaskActivity.this, "Task inserted!", Toast.LENGTH_LONG).show();
                    }else{
                        //show input error
                        Toast.makeText(AddTaskActivity.this, "INVALID INPUT, PLEASE CHECK AGAIN!", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(AddTaskActivity.this, "EMPTY INPUT !", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void viewTask(){
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor task_data = myDB.showTaskData();

                if(task_data.getCount() == 0){
                    //message
                    display("Error","NO Data Found.");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(task_data.moveToNext()){
                    buffer.append("ID: " + task_data.getString(0) + "\n");
                    buffer.append("Name: " + task_data.getString(1) + "\n");
                    buffer.append("Des: " + task_data.getString(2) + "\n");
                    buffer.append("Priority: " + task_data.getString(3) + "\n");

                    //display message
                    display("ALL stored data:", buffer.toString());
                }
            }
        });
    }

    public void display(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }


}
