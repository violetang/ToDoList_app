package com.example.violetang.navigationbuttom;


import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class TaskFragment extends Fragment {


    ListView myToDoTasksList;
    ListView myComTasksList;

    ImageView tasktoolBarSetting;
    ImageView tasktoolbarAdd;

    //DatabaseHelper myDB;

    public TaskFragment() {
        // Required empty public constructor
    }

        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

            Resources res =getResources();
            View view = inflater.inflate(R.layout.fragment_task, container, false);

            //myDB = new DatabaseHelper(getActivity());

            //Two listView (todo + complete)
            myToDoTasksList = (ListView)view.findViewById(R.id.tasklist_ListView);
            myComTasksList = (ListView)view.findViewById(R.id.completelist_ListView);

            //items and description
            String[] taskItems = res.getStringArray(R.array.taskItems);
            String[] taskDes = res.getStringArray(R.array.taskDescription);
            //ArrayList<String> taskItems = new ArrayList<>();
            // ArrayList<String> taskDes = new ArrayList<>();

            //ArrayList<String> completeItems = new ArrayList<>();
            //ArrayList<String> completeItemsDes = new ArrayList<>();
            String[] completeItems = res.getStringArray(R.array.taskItemsCompleted);
            String[] completeItemsDes = res.getStringArray(R.array.taskDescriptionCompleted);

            //Cursor todo_task_data = myDB.getTodoTask();
            //Cursor completeTask_task_data = myDB.getCompleteTask();

            //adapter for todo task

            /*
            while(todo_task_data.moveToNext()) {
                taskItems.add(todo_task_data.getString(1));
                taskDes.add(todo_task_data.getString(2));
            }*/
            ItemAdapter taskItemAdapter = new ItemAdapter(MyApplication.getAppContext(), taskItems, taskDes);
            myToDoTasksList.setAdapter(taskItemAdapter);

            //adapter for complete task
            /*
            while(completeTask_task_data.moveToNext()) {
                taskItems.add(completeTask_task_data.getString(1));
                taskDes.add(completeTask_task_data.getString(2));
            }*/
            ItemAdapter completeAdapter = new ItemAdapter(MyApplication.getAppContext(),completeItems,completeItemsDes);
            myComTasksList.setAdapter(completeAdapter);

            //tool bar ImageView(setting + adding)
            tasktoolBarSetting = (ImageView)view.findViewById(R.id.listbar_setting);
            tasktoolbarAdd = (ImageView)view.findViewById(R.id.listbar_addNewList);

            tasktoolbarAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent Addtask_Intent = new Intent(tasktoolbarAdd.getContext(),AddTaskActivity.class);
                    //send an personal object to the personal page
                    startActivity(Addtask_Intent);
                    //Toast.makeText(MyApplication.getAppContext(), " Install Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                }
            });

            tasktoolBarSetting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    switch (v.getId()) {
                        case R.id.listbar_setting:

                            PopupMenu popup = new PopupMenu(MyApplication.getAppContext(), v);
                            popup.getMenuInflater().inflate(R.menu.titlebar_settingmenu, popup.getMenu());
                            popup.show();
                            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                @Override
                                public boolean onMenuItemClick(MenuItem item) {
                                    switch (item.getItemId()) {
                                        case R.id.titleBar_Setting_Pinfo:

                                            Intent PersonInfo_Intent = new Intent(tasktoolBarSetting.getContext(),personalInfoActivity.class);
                                            //send an personal object to the personal page
                                            startActivity(PersonInfo_Intent);
                                            //Toast.makeText(MyApplication.getAppContext(), " Install Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                            break;
                                        case R.id.titleBar_Setting_Setting:

                                            //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();
                                            Intent Setting_Intent = new Intent(tasktoolBarSetting.getContext(),personalInfoActivity.class);
                                            startActivity(Setting_Intent);
                                            break;

                                        case R.id.titleBar_Setting_About:
                                            Intent About_Intent = new Intent(tasktoolBarSetting.getContext(), AboutActivity.class);
                                            //send any info to about page
                                            startActivity(About_Intent);
                                            //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();
                                            break;

                                        default:
                                            break;
                                    }
                                    return true;
                                }
                            });
                            break;
                        default:
                            break;
                    }
                }
            });

            return view;
    }


}
