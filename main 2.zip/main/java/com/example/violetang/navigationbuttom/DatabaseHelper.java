package com.example.violetang.navigationbuttom;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper{

    private static final String DATABASE_NAME = "todo.db";
    private static final String TASK_TABLE_NAME = "task_table";
    private static final String TASK_COL0_ID= "ID";
    private static final String TASK_COL1_NAME= "NAME";
    private static final String TASK_COL2_DES= "DES";
    private static final String TASK_COL3_DATE= "DATE";
    private static final String TASK_COL4_TIME= "TIME";
    private static final String TASK_COL5_STATUS = "STATUS";
    private static final String TASK_COL6_PRI= "PRI";
    private static final String TASK_COL7_LIST= "LIST";

    private String create_task_table_statement = "CREATE TABLE "+ TASK_TABLE_NAME +" ( "+TASK_COL0_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+ TASK_COL1_NAME+
            " TEXT NOT NULL, "+TASK_COL2_DES+" TEXT, "+TASK_COL5_STATUS+" INTEGER, "+TASK_COL6_PRI+" INTEGER );";


    private static final String LIST_TABLE_NAME = "task_table";
    private static final String LIST_COL1= "ID";
    private static final String LIST_COL2= "NAME";
    private static final String LIST_COL3= "DES";
    private static final String LIST_COL4= "PRI";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //sql create all the tables and cols
        //create the task table
        db.execSQL(create_task_table_statement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //changes in database;
        db.execSQL("DROP TABLE IF EXISTS " + TASK_TABLE_NAME);
        onCreate(db);
    }

    //parameter can be a task object
    public boolean addTaskData( String name, String des, int pri){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TASK_COL1_NAME,name);
        contentValues.put(TASK_COL2_DES,des);
        contentValues.put(TASK_COL5_STATUS,0);
        contentValues.put(TASK_COL6_PRI,pri);

        long result = db.insert(TASK_TABLE_NAME,null,contentValues);
        if(result == -1){
            return false;
        }else{
            return true;
        }
    }

    public  Cursor getTodoTask(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor todo_task_data = db.rawQuery("SELECT * FROM "+TASK_TABLE_NAME+" WHERE "+TASK_COL5_STATUS+" = 0", null);
        return todo_task_data;
    }

    public  Cursor getCompleteTask(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor complete_task_data = db.rawQuery("SELECT * FROM "+TASK_TABLE_NAME+" WHERE "+TASK_COL5_STATUS+" = 1", null);
        return complete_task_data;
    }

    public  Cursor getTodoTaskOfList(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor todo_task_data = db.rawQuery("SELECT * FROM "+TASK_TABLE_NAME+" WHERE "+TASK_COL5_STATUS+" = 0", null);
        return todo_task_data;
    }

    public  Cursor getCompleteTaskOfList(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor complete_task_data = db.rawQuery("SELECT * FROM "+TASK_TABLE_NAME+" WHERE "+TASK_COL5_STATUS+" = 1", null);
        return complete_task_data;
    }

    public Cursor showTaskData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor task_data = db.rawQuery("SELECT * FROM "+TASK_TABLE_NAME, null);
        return task_data;
    }
}
