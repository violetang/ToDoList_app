package com.example.violetang.navigationbuttom;

import android.content.Context;
import android.icu.util.Calendar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CalendarAdapter extends BaseAdapter {

    LayoutInflater mInflater;

    ArrayList<String> task_items;
    ArrayList<String> task_descriptions;
    ArrayList<Integer>task_id;

    //CheckBox[] task_checkbox;

    //modify the constructor add new parameter date
    public CalendarAdapter(Context c, ArrayList<Integer> id, ArrayList<String> i, ArrayList<String> d){
        task_id = id;
        task_items = i;
        task_descriptions = d;
        mInflater = (LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return task_items.size();
    }

    @Override
    public Object getItem(int position) {
        return task_items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = mInflater.inflate(R.layout.item_task, null);
        TextView nameTextView = (TextView)v.findViewById(R.id.taskName_TextView);
        TextView decriptionTextView = (TextView) v.findViewById(R.id.taskDes_TextView);
        //CheckBox taskCheckBox = (CheckBox)v.findViewById(R.id.taskCheckBox);

        final int index = position;
        String name = task_items.get(position);
        String desc = task_descriptions.get(position);
        //CheckBox checkbox = task_checkbox[position];

        nameTextView.setText(name);
        decriptionTextView.setText(desc);
        //taskCheckBox.onCheckboxClicked(checkbox);

        return v;
    }

}