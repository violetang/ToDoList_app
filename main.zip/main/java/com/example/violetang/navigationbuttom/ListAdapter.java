package com.example.violetang.navigationbuttom;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

public class ListAdapter extends BaseAdapter {

    LayoutInflater mInflater;
    String[] list_items;

    public ListAdapter(Context c, String[] l) {
        list_items = l;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list_items.length;
    }

    @Override
    public Object getItem(int position) {
        return list_items[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = mInflater.inflate(R.layout.item_list, null);
        TextView nameTextView = (TextView) v.findViewById(R.id.listName_textView);

        String name = list_items[position];
        nameTextView.setText(name);

        return v;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }
}
