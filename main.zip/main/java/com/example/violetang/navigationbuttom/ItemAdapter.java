package com.example.violetang.navigationbuttom;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;

public class ItemAdapter extends BaseAdapter {

    LayoutInflater mInflater;
    String[] task_items;
    String[] task_descriptions;
    //CheckBox[] task_checkbox;
    //Spinner taskAction_spinner;

    public ItemAdapter(Context c, String[] i, String[] d){
        task_items = i;
        task_descriptions = d;
        //taskAction_spinner = spinner;
        mInflater = (LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return task_items.length;
    }

    @Override
    public Object getItem(int position) {
        return task_items[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = mInflater.inflate(R.layout.item_task, null);
        TextView nameTextView = (TextView)v.findViewById(R.id.taskName_TextView);
        TextView decriptionTextView = (TextView) v.findViewById(R.id.taskDes_TextView);
        //CheckBox taskCheckBox = (CheckBox)v.findViewById(R.id.taskCheckBox);
       // Spinner Spinner = (Spinner) v.findViewById(R.id.TaskAction_spinner);

        String name = task_items[position];
        String desc = task_descriptions[position];
        //CheckBox checkbox = task_checkbox[position];
        //Spinner spinner = taskAction_spinner;

        nameTextView.setText(name);
        decriptionTextView.setText(desc);
        //taskCheckBox.onCheckboxClicked(checkbox);

        return v;
    }

    /*
    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.checkbox_meat:
                if (checked)
                // Put some meat on the sandwich
            else
                // Remove the meat
                break;
            case R.id.checkbox_cheese:
                if (checked)
                // Cheese me
            else
                // I'm lactose intolerant
                break;
            // TODO: Veggie sandwich
        }
    }
    */
}