package com.example.violetang.navigationbuttom;


import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListFragment extends Fragment {

    DatabaseHelper myDB;

    ImageView setting;
    ImageView addNewList;

    String[] list;
    ListView listBar;

    ArrayList<Integer> todoTasksId = new ArrayList<>();
    ArrayList<String> todoTasks = new ArrayList<>();
    ArrayList<String> todoTasksDes = new ArrayList<>();

    ArrayList<Integer> ComTasksId = new ArrayList<>();
    ArrayList<String> completeTask = new ArrayList<>();
    ArrayList<String> completeTaskDes = new ArrayList<>();


    ListView tasksOfTheList_todo;
    ListView getTasksOfTheList_complete;

    public ListFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        myDB = new DatabaseHelper(MyApplication.getAppContext());

        Resources res =getResources();
        View view = inflater.inflate(R.layout.fragment_list, container, false);

        //Tool bar
        setting = (ImageView)view.findViewById(R.id.listbar_setting);
        addNewList = (ImageView)view.findViewById(R.id.listbar_addNewList);
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.listbar_setting:

                        PopupMenu popup = new PopupMenu(MyApplication.getAppContext(), v);
                        popup.getMenuInflater().inflate(R.menu.titlebar_settingmenu, popup.getMenu());
                        popup.show();
                        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.titleBar_Setting_Pinfo:
                                        //Or Some other code you want to put here.. This is just an example.
                                        //Toast.makeText(MyApplication.getAppContext(), item.getTitle(), Toast.LENGTH_LONG).show();
                                        Intent PersonInfo_Intent = new Intent(setting.getContext(),personalInfoActivity.class);
                                        //send an personal object to the personal page
                                        startActivity(PersonInfo_Intent);

                                        break;
                                    case R.id.titleBar_Setting_Setting:
                                        //Toast.makeText(MyApplication.getAppContext(), item.getTitle(), Toast.LENGTH_LONG).show();
                                        Intent Setting_Intent = new Intent(setting.getContext(),personalInfoActivity.class);
                                        startActivity(Setting_Intent);
                                        break;

                                    case R.id.titleBar_Setting_About:
                                        //Toast.makeText(MyApplication.getAppContext(), item.getTitle(), Toast.LENGTH_LONG).show();
                                        Intent About_Intent = new Intent(setting.getContext(), AboutActivity.class);
                                        //send any info to about page
                                        startActivity(About_Intent);

                                        break;

                                    default:
                                        break;
                                }
                                return true;
                            }
                        });
                        break;
                    default:
                        break;
                }
            }
        });

        //left list Bar
        listBar = (ListView)view.findViewById(R.id.listNavBar);

        list = res.getStringArray(R.array.myList);//get info from database

        ListAdapter ListItemAdapter = new ListAdapter(MyApplication.getAppContext(),list);
        listBar.setAdapter(ListItemAdapter);

        //right task bar
        tasksOfTheList_todo = (ListView)view.findViewById(R.id.taskBartodo_ListView);
        getTasksOfTheList_complete = (ListView)view.findViewById(R.id.taskBarcomplete_ListView);

        listBar.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                view.setSelected(true);

                //database query: get corresponding task by list_id
                Cursor todo_task_data = myDB.getTodoTaskOfList();
                Cursor completeTask_task_data = myDB.getCompleteTaskOfList();

                while(todo_task_data.moveToNext()) {
                    todoTasksId.add(todo_task_data.getInt(0));
                    todoTasks.add(todo_task_data.getString(1));
                    todoTasksDes.add(todo_task_data.getString(2));
                }

                ItemAdapterTest taskItemAdapter = new ItemAdapterTest(MyApplication.getAppContext(),todoTasksId,todoTasks,todoTasksDes);
                tasksOfTheList_todo.setAdapter(taskItemAdapter);
               
                setDynamicHeight(tasksOfTheList_todo); //set dynmic height for listview


                while(completeTask_task_data.moveToNext()) {
                    ComTasksId.add(completeTask_task_data.getInt(0));
                    completeTask.add(completeTask_task_data.getString(1));
                    completeTaskDes.add(completeTask_task_data.getString(2));
                }
//                ItemAdapterTest completeAdapter = new ItemAdapterTest(MyApplication.getAppContext(),ComTasksId,completeTask,completeTaskDes);
//                getTasksOfTheList_complete.setAdapter(completeAdapter);
//                setDynamicHeight(getTasksOfTheList_complete); //set dynmic height for listview
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    public static void setDynamicHeight(ListView listView) {
        ItemAdapterTest adapter = (ItemAdapterTest)listView.getAdapter();
        //check adapter if null
        if (adapter == null) {
            return;
        }
        int height = 0;
        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.UNSPECIFIED);
        for (int i = 0; i < adapter.getCount(); i++) {
            View listItem = adapter.getView(i, null, listView);
            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            height += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams layoutParams = listView.getLayoutParams();
        layoutParams.height = height + (listView.getDividerHeight() * (adapter.getCount() - 1));
        listView.setLayoutParams(layoutParams);
        listView.requestLayout();
    }



}
