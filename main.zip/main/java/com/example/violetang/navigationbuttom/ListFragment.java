package com.example.violetang.navigationbuttom;


import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListFragment extends Fragment {

    //RelativeLayout toolbar;
    ImageView setting;
    //ImageView addNewList;


    public ListFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Resources res =getResources();
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        setting = (ImageView)view.findViewById(R.id.listbar_setting);
        //addNewList = (ImageView)view.findViewById(R.id.listbar_addNewList);
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.listbar_setting:

                        PopupMenu popup = new PopupMenu(MyApplication.getAppContext(), v);
                        popup.getMenuInflater().inflate(R.menu.titlebar_settingmenu, popup.getMenu());
                        popup.show();
                        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.titleBar_Setting_Pinfo:

                                        //Or Some other code you want to put here.. This is just an example.
                                        //Toast.makeText(MyApplication.getAppContext(), " Install Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                        break;
                                    case R.id.titleBar_Setting_Setting:

                                        //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                        break;

                                    case R.id.titleBar_Setting_About:

                                        //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                        break;

                                    default:
                                        break;
                                }

                                return true;
                            }
                        });
                        break;
                    default:
                        break;
                }
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

}
