package com.example.violetang.navigationbuttom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class ItemAdapterTest extends BaseAdapter {

    LayoutInflater mInflater;
    ArrayList<String> task_items;
    ArrayList<String> task_descriptions;
    ArrayList<Integer>task_id;

    private DatabaseHelper myDB;
    private DBManager dbManager;

    private Context context;
    //private ArrayList<String> integers = new ArrayList<>();

    //CheckBox[] task_checkbox;

    public ItemAdapterTest(Context c, ArrayList<Integer> id, ArrayList<String> i, ArrayList<String> d) {
        task_id = id;
        task_items = i;
        task_descriptions = d;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        dbManager = new DBManager(c);
        dbManager.open();
        context =c;

    }

    @Override
    public int getCount() {


        return task_items.size();
    }

    @Override
    public Object getItem(int position) {
        return task_items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

         Cursor cursor =  dbManager.fetch();
         cursor.move(position);
         Log.d("columnin",""+cursor.getInt(1)+cursor.getInt(0));

         View v = mInflater.inflate(R.layout.item_task, null);
            myDB = new DatabaseHelper(MyApplication.getAppContext());

        TextView nameTextView = (TextView) v.findViewById(R.id.taskName_TextView);
        TextView decriptionTextView = (TextView) v.findViewById(R.id.taskDes_TextView);
        CheckBox taskCheckBox = (CheckBox)v.findViewById(R.id.taskCheckBox);

        if(cursor.getInt(1)==1) {
            taskCheckBox.setChecked(true);
        }
        else
            taskCheckBox.setChecked(false);
        ImageView imageView = (ImageView) v.findViewById(R.id.taskMenu_ImageView);

        final int index = position;

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.taskMenu_ImageView:

                        PopupMenu popup = new PopupMenu(MyApplication.getAppContext(), v);
                        popup.getMenuInflater().inflate(R.menu.taskitem_menu, popup.getMenu());
                        popup.show();
                        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.taskItemMenuEdit:

                                        //Or Some other code you want to put here.. This is just an example.
                                        Toast.makeText(MyApplication.getAppContext(), " Install Clicked at position " + " : " + index, Toast.LENGTH_LONG).show();

                                        break;
                                    case R.id.taskItemMenuDelete:
                                        int id = task_id.get(index);
                                        myDB.deleteTaskbyId(id);
                                        task_id.remove(index);
                                        task_descriptions.remove(index);
                                        task_items.remove(index);


                                        //Delete
                                        dbManager.update(position,0);

                                        //Toast.makeText(MyApplication.getAppContext(), "task " + id+" was deleted", Toast.LENGTH_LONG).show();
                                        break;

                                    case R.id.taskItemMenuShare:
                                        //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                        break;

                                    default:
                                        break;
                                }

                                return true;
                            }
                        });
                        break;
                    default:
                        break;
                }
            }
        });

        String name = task_items.get(position);
        String desc = task_descriptions.get(position);
        //CheckBox checkbox = task_checkbox[position];

        nameTextView.setText(name);
        decriptionTextView.setText(desc);
       taskCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    dbManager.update(position,1);
                }
                else{
                    dbManager.update(position,0);
                }
           }
       });

        return v;
    }

}
