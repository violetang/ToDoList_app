package com.example.violetang.navigationbuttom;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.CheckBox;

public class DBManager {

    private CheckDatabaseHelper dbHelper;

    private Context context;

    private SQLiteDatabase database;

    public DBManager(Context c) {
        context = c;
    }

    public DBManager open() throws SQLException {
        dbHelper = new CheckDatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public void insert(Integer name, Integer desc) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(CheckDatabaseHelper.Position, name);
        contentValue.put(CheckDatabaseHelper.ISCHECKED,desc);
        database.insert(CheckDatabaseHelper.TABLE_NAME, null, contentValue);
    }

    public Cursor fetch() {
        String[] columns = new String[] { CheckDatabaseHelper.Position, CheckDatabaseHelper.ISCHECKED};
        Cursor cursor = database.query(CheckDatabaseHelper.TABLE_NAME, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public int update(Integer position,Integer ischek) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(CheckDatabaseHelper.Position, position);
        contentValues.put(CheckDatabaseHelper.ISCHECKED, ischek);
        int i = database.update(CheckDatabaseHelper.TABLE_NAME, contentValues, CheckDatabaseHelper.Position + " = " + position, null);
        return i;
    }

    public void delete(Integer poisiton) {
        database.delete(CheckDatabaseHelper.TABLE_NAME, CheckDatabaseHelper.Position + "=" + poisiton, null);
    }

}