package com.example.violetang.navigationbuttom;


import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;

/**
 * A simple {@link Fragment} subclass.
 */
public class TaskFragment extends Fragment {

    //private Spinner spinner;
    ListView myToDoTasksList;
    ListView myComTasksList;

    String[] taskItems;
    String[] taskDes;

    String[] completeItems;
    String[] completeItemsDes;

    ImageView tasktoolBarSetting;
    ImageView tasktoolbarAdd;

    public TaskFragment() {
        // Required empty public constructor
    }

        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Resources res =getResources();
        View view = inflater.inflate(R.layout.fragment_task, container, false);
        myToDoTasksList = (ListView)view.findViewById(R.id.tasklist_ListView);
        myComTasksList = (ListView)view.findViewById(R.id.completelist_ListView);
        taskItems = res.getStringArray(R.array.taskItems);
        taskDes = res.getStringArray(R.array.taskDescription);
        completeItems = res.getStringArray(R.array.taskItemsCompleted);
        completeItemsDes = res.getStringArray(R.array.taskDescriptionCompleted);
        tasktoolBarSetting = (ImageView)view.findViewById(R.id.listbar_setting);
        tasktoolbarAdd = (ImageView)view.findViewById(R.id.listbar_addNewList);

        ItemAdapter taskItemAdapter = new ItemAdapter(super.getContext(),taskItems,taskDes);
        myToDoTasksList.setAdapter(taskItemAdapter);

        ItemAdapter completeAdapter = new ItemAdapter(super.getContext(),completeItems,completeItemsDes);
        myComTasksList.setAdapter(completeAdapter);

            tasktoolBarSetting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    switch (v.getId()) {
                        case R.id.listbar_setting:

                            PopupMenu popup = new PopupMenu(MyApplication.getAppContext(), v);
                            popup.getMenuInflater().inflate(R.menu.titlebar_settingmenu, popup.getMenu());
                            popup.show();
                            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                @Override
                                public boolean onMenuItemClick(MenuItem item) {
                                    switch (item.getItemId()) {
                                        case R.id.titleBar_Setting_Pinfo:

                                            //Or Some other code you want to put here.. This is just an example.
                                            //Toast.makeText(MyApplication.getAppContext(), " Install Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                            break;
                                        case R.id.titleBar_Setting_Setting:

                                            //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                            break;

                                        case R.id.titleBar_Setting_About:

                                            //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                            break;

                                        default:
                                            break;
                                    }

                                    return true;
                                }
                            });
                            break;
                        default:
                            break;
                    }
                }
            });

            return view;
    }


}
