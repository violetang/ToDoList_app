package com.example.violetang.navigationbuttom;


import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;

/**
 * A simple {@link Fragment} subclass.
 */
public class TaskFragment extends Fragment {

    //private Spinner spinner;
    ListView myToDoTasksList;
    ListView myComTasksList;

    String[] taskItems;
    String[] taskDes;

    String[] completeItems;
    String[] completeItemsDes;

    ImageView tasktoolBarSetting;
    ImageView tasktoolbarAdd;

    public TaskFragment() {
        // Required empty public constructor
    }

        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Resources res =getResources();
        View view = inflater.inflate(R.layout.fragment_task, container, false);

        //Two listView (todo + complete)
        myToDoTasksList = (ListView)view.findViewById(R.id.tasklist_ListView);
        myComTasksList = (ListView)view.findViewById(R.id.completelist_ListView);

        //items and description
        taskItems = res.getStringArray(R.array.taskItems);
        taskDes = res.getStringArray(R.array.taskDescription);
        completeItems = res.getStringArray(R.array.taskItemsCompleted);
        completeItemsDes = res.getStringArray(R.array.taskDescriptionCompleted);

        //tool bar ImageView(setting + adding)
        tasktoolBarSetting = (ImageView)view.findViewById(R.id.listbar_setting);
        tasktoolbarAdd = (ImageView)view.findViewById(R.id.listbar_addNewList);

        //adapter for todo task
        ItemAdapter taskItemAdapter = new ItemAdapter(super.getContext(),taskItems,taskDes);
        myToDoTasksList.setAdapter(taskItemAdapter);

        //adapter for complete task
        ItemAdapter completeAdapter = new ItemAdapter(super.getContext(),completeItems,completeItemsDes);
        myComTasksList.setAdapter(completeAdapter);

            tasktoolBarSetting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    switch (v.getId()) {
                        case R.id.listbar_setting:

                            PopupMenu popup = new PopupMenu(MyApplication.getAppContext(), v);
                            popup.getMenuInflater().inflate(R.menu.titlebar_settingmenu, popup.getMenu());
                            popup.show();
                            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                @Override
                                public boolean onMenuItemClick(MenuItem item) {
                                    switch (item.getItemId()) {
                                        case R.id.titleBar_Setting_Pinfo:

                                            Intent PersonInfo_Intent = new Intent(tasktoolBarSetting.getContext(),personalInfoActivity.class);
                                            //send an personal object to the personal page
                                            startActivity(PersonInfo_Intent);
                                            //Toast.makeText(MyApplication.getAppContext(), " Install Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();

                                            break;
                                        case R.id.titleBar_Setting_Setting:

                                            //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();
                                            Intent Setting_Intent = new Intent(tasktoolBarSetting.getContext(),personalInfoActivity.class);
                                            startActivity(Setting_Intent);
                                            break;

                                        case R.id.titleBar_Setting_About:
                                            Intent About_Intent = new Intent(tasktoolBarSetting.getContext(), AboutActivity.class);
                                            //send any info to about page
                                            startActivity(About_Intent);
                                            //Toast.makeText(MyApplication.getAppContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();
                                            break;

                                        default:
                                            break;
                                    }
                                    return true;
                                }
                            });
                            break;
                        default:
                            break;
                    }
                }
            });

            return view;
    }


}
