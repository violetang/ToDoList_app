package com.example.violetang.navigationbuttom;


import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;


/**
 * A simple {@link Fragment} subclass.
 */
public class TaskFragment extends Fragment {

    //private Spinner spinner;
    ListView myToDoTasksList;
    ListView myComTasksList;
    String[] taskItems;
    String[] taskDes;

    public TaskFragment() {
        // Required empty public constructor
    }

        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Resources res =getResources();
        View view = inflater.inflate(R.layout.fragment_task, container, false);
        myToDoTasksList = (ListView)view.findViewById(R.id.tasklist_ListView);
        taskItems = res.getStringArray(R.array.taskItems);
        taskDes = res.getStringArray(R.array.taskDescription);

        //ListAdapter listAdapter = new ListAdapter(getActivity(),android.R.simple_list_item_1, taskItems);
        ItemAdapter taskItemAdapter = new ItemAdapter(super.getContext(),taskItems,taskDes);
        myToDoTasksList.setAdapter(taskItemAdapter);


        return view;
    }


}
