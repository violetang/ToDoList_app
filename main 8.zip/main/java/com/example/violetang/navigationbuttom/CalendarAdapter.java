package com.example.violetang.navigationbuttom;

import android.content.Context;
import android.icu.util.Calendar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CalendarAdapter extends BaseAdapter {

    LayoutInflater mInflater;
    String[] task_items;
    String[] task_descriptions;
    String[] task_date; // add new variable task date
    ItemAdapter a;
    Object[] tasks;

    //CheckBox[] task_checkbox;
    //Spinner taskAction_spinner;

    //modify the constructor add new parameter date
    public CalendarAdapter(Context c, String[] i, String[] d, String[] date){
        task_items = i;
        task_descriptions = d;
        task_date = date;
        //taskAction_spinner = spinner;
        mInflater = (LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    //method to get date of a task
    public String getDate(int position){
        return task_date[position];
    }

    @Override
    public int getCount() {
        return task_items.length;
    }

    @Override
    public Object getItem(int position) {
        return task_items[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = mInflater.inflate(R.layout.item_task, null);
        TextView nameTextView = (TextView)v.findViewById(R.id.taskName_TextView);
        TextView decriptionTextView = (TextView) v.findViewById(R.id.taskDes_TextView);
        //CheckBox taskCheckBox = (CheckBox)v.findViewById(R.id.taskCheckBox);
        // Spinner Spinner = (Spinner) v.findViewById(R.id.TaskAction_spinner);

        String name = task_items[position];
        String desc = task_descriptions[position];
        //CheckBox checkbox = task_checkbox[position];
        //Spinner spinner = taskAction_spinner;

        nameTextView.setText(name);
        decriptionTextView.setText(desc);
        //taskCheckBox.onCheckboxClicked(checkbox);

        return v;
    }

}